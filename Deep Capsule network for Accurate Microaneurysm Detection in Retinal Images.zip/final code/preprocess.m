clc;
clear all;
close all;
warning off;
Image=imread('3.jpg');
I=Image(:,:,2);
figure,imshow(I);title('Green Channel Image');
[m n]=size(I);
J1 = adapthisteq(I);
figure,imshow(J1);
SE1=strel('square',2);
IC1=imclose(J1,SE1);
figure,imshow(IC1);
IF1=imfill(IC1,'holes');
figure,imshow(IF1);
diff_img=imsubtract(IF1,IC1);
figure,imshow(diff_img);
level1 = graythresh(diff_img);
IB1=im2bw(diff_img,level1);
figure,imshow(IB1);
BW1 = ~imextendedmin(diff_img,20);
figure,imshow(BW1);


% Find Exudates
B1 = medfilt2(I, [5 5]);
figure,imshow(B1);
marker = imsubtract(B1,30);
figure,imshow(marker);
IM1 = imreconstruct(marker,B1);
bkg_img1=imsubtract(I,IM1);
figure,imshow(bkg_img1);
level2 = graythresh(bkg_img1);
IB2=im2bw(bkg_img1,level2);
figure,imshow(IB2);
CC=bwconncomp(IB2);
S = regionprops(CC, 'Area');
I2 = bwareaopen(IB2, 6000);
figure,imshow(I2);
I_exudates=imsubtract(IB2,I2);
figure,imshow(I_exudates);

% Find Blood Vessels
J3 = adapthisteq(I);
figure,imshow(J3);
%Extract Blood Vessels
Threshold = 10;
bloodVessels = VesselExtract(J3, Threshold);
SE2=strel('square',2);
IER1=imerode(bloodVessels,SE2);
IER2=imerode(IER1,SE2);
IS3=immultiply(IER2,double(I));
IF3=imfill(IS3,'holes');
figure,imshow(IF3);
level3 = graythresh(IF3);
IB3=im2bw(IF3,level3);
figure,imshow(IB3);


% Find Microneurysm

for i=1:m
    for j=1:n
        IMA(i,j)=double(BW1(i,j))-double(IB3(i,j))-double(I_exudates(i,j));
    end
end
level4 = graythresh(IMA);
I_micro=~im2bw(IMA,level4);
figure,imshow(I_micro);